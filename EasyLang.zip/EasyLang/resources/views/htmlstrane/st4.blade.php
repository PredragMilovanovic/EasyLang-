


@extends('layouts.app')

@section('content')

<div id="myCarousel" class="carousel slide" data-ride="carousel">

  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

 <div class="carousel-inner" role="listbox">

    <div class="item active">
        <img class="first-slide" src="https://lonelyplanetimages.imgix.net/a/g/hi/t/09a64fea2933f6da77ab07d671d1f678-south-korea.jpg?sharp=10&vib=20&w=1200" alt="First Slide"style="height: 500px; width: 100%; display: block;">
        <div class="container">
            <div class="carousel-caption" style=" font-weight:bold; height: 100%; font-weight:bold;">
                <h1>Naucite korejski besplatno!</h1>
                <h4>Nas kurs besplatnog ucenja korejskog jezika pomocice vam u tome!</h4>
            </div>
        </div>
    </div>

    <div class="item">
        <img class="second-slide" src="http://assets.signature-reads.com/wp-content/uploads/2017/09/education-quotes-shutterstock.jpg" alt="Second Slide" style="height: 500px; width: 100%; display: block;">
        <div class="container">
            <div class="carousel-caption" style=" font-weight:bold; height: 100%; font-weight:bold;">
                <h1>Ucenje je brzo i efikasno</h1>
                <h4>Ovim kursom korejskog jezika moci cete doseći A2 nivo Zajednickog evropskog referentnog okvira.</h4>
            </div>
        </div>
    </div>

    <div class="item">
        <img class="second-slide" src="https://www.learnupon.com/wp-content/uploads/create-engaging-mobile-learning-content.jpg" alt="Third Slide" style="height: 500px; width: 100%; display: block;">
        <div class="container">
            <div class="carousel-caption" style=" font-weight:bold; height: 100%; font-weight:bold;">
                <h1>Uvek dostupan</h1>
                <h4>Sajt je prilagodjen telefonima, tako da cete lako moci citati lekcije dok ste na primer u autobusu.</h4>
            </div>
        </div>
    </div>
 </div>

   <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Prethodna</span>
   </a>
   <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Sledeca</span>
    </a>

</div>
@endsection



