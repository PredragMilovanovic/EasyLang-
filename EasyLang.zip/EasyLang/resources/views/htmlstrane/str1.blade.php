@extends('layouts.app')

@section('content')

<div class=" container">
<nav class="col-md-2 d-none d-md-block bg-light sidebar-static" style=" height: 100%;width: 160px;position: fixed;z-index: 1;top: 0;left: 0;background-color: #111;overflow-x: hidden;padding-top: 20px; margin-top:40px;">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
            <li class="nav-item">
            
            <form method="get" action="{{url('/searchcontent')}}" class="navbar-form navbar-lefte" role="search">
            <div class="input-group custom-search-form ">
            <input type="text" class="form-control" name="search" placeholder="Trazi">
            <span class="input-group-btn">
            <button class="btn btn-default-sm" type="submit">
            <i class="fa fa-search"> *</i>
             </button>
            </span>
           </div>
          </form>


            </li>
              <li class="nav-item">
                <a class="nav-link active" href="{{ url('/home') }}">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                  Pocetna <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/lessons">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file-text"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                  Lekcije
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/contents">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
                  Kategorije
                </a>
              </li>
             
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bar-chart-2"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
                  Izvestaj
                </a>
              </li>
             
            </ul>

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Dodaj novu lekciju</span>
              <a class="d-flex align-items-center text-muted" href="/lessons/create">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
              </a>
            </h6>

            <ul class="nav flex-column mb-2">

            <li class="nav-item">
                <a class="nav-link" href="{{ url('/dashboard') }}">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                  Chat
                </a>
              </li>

            <li class="nav-item">
                <a class="nav-link" href="{{ url('/contact') }}">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                  Kontaktiraj nas
                </a>
              </li>
            </ul>

          </div>
        </nav>




<div class="starter-template col-md-7 col-md-offset-2" style="white-space: pre-wrap; margin-top:80px;">
  <h1>Međunarodno priznat standard za učenje korejskog jezika</h1>
  <p>Kako škole stranih jezika posluju u skladu sa važećim standardima u nastavi jezika, to isto važi i kada je u pitanju kurs korejskog jezika. A kako je učenje ovog jezika usklađeno sa pravilima Zajedničkog evropskog referentnog okvira, odnosno CEFR - a (The Common European Framework of  Reference for Languages), to podrazumeva da se nastava učenja korejskog kao stranog jezika održava u 6 nivoa. Kada se kaže 6 nivoa, zapravo se misli na nivoe grupe A (Početni, odnosno Osnovni), preko nivoa grupe B (Srednji), pa do Naprednih nivoa C grupe. U okviru svake od navedenih grupa, zapravo postoji po 2 podnivoa i to : A 1 i A 2 (Niži i Viši početni nivo), B 1 i B 2 (Niži i Viši srednji nivo) i C 1 i C 2 (Niži i Viši napredni nivo).</p>
  <p>Uzevši u obzir da je učenje korejskog jezika širom sveta usklađeno sa ovim pravilima, tako svaki kandidat po uspešno savladanom određenom nivou znanja polaže ispit provere, kako bi se utvrdilo da li je savladao znanja koja se očekuju od njega na tom nivou. Tek nakon što uspešno položi ovaj ispit, polaznik može da pređe na sledeći nivo ili, u zavisnosti od nivoa da polaže ispit za sticanje međunarodno priznatog sertifikata o znanju korejskog kao stranog jezika. Po uspešnom završetku svakog nivoa kursa korejskog jezika Akademije Oxford polaznik stiče potvrdu o pohađanju određenog nivoa, koja je izuzetno važna ukoliko jednog dana odluči da polaže ispit za sticanje sertifikata, stim što se pimenuti ispit za sticanje sertifikata može polagati tek po završetku viših nivoa znanja jezika.</p>
  <p>Najkraće rečeno, kako je <strong> A 1 nivo</strong>, zapravo Početni odnosno Osnovni nivo znanja, sasvim je jasno da je on osnov učenja jezika i da se za pohađanje kursa korejskog A 1 nivoa ne očekuje da kandidat ima bilo kakvo predznanje, već jednostavno želju da nauči ovaj jezik. Naravno, ukoliko želi da upiše bilo koji od ostalih 5 nivoa, ipak se očekuje da poseduje određeno predznanje. Dakle, kada završi ovaj kurs kandidat bi trebalo da zna da napiše, kaže i pročita osnovne reči i izraze, to jest one koju su najčešće u upotrebi, kao i da se predstavi i kaže osnovne podatke o svom životu i porodici.</p>
  <p>Već, Viši početni nivo odnosno <strong> A 2 nivo</strong> podrazumeva da je polaznik savladao prethodni nivo, odnosno da ima osnovno predznanje o jeziku. A po završenom kursu korejskog A 2 nivoa, on bi trebalo da je sposoban da priča opširnije o svom životu, poslu, školi,studiranju i uobičajenim temama, te da zna da se snađe recimo kada ode u kupovinu ili hotel. </p>
  <p>Od kandidata koji je savladao Niži srednji nivo, odnosno koji je uspešno završio kurs korejskog <strong>B 1 nivoa</strong>  se naravno, očekuje još viši stepen znanja. On može da razgovara sa osobama kojima je korejski maternji, ali isključivo o temama koje su mu u potpunosti bliske. Pa čak i tada se od njega ne očekuje da razume baš svaku reč, ali se očekuje da razume smisao razgovora. Možda čak i uspe da odgovori na pitanje, ali neophodno je da njegov sagovornik govori sporo i razgovetno i da je spreman da mu pomogne, to jest eventualno da ponovi pitanje ukoliko ga polaznik nije u potpunosti razumeo.</p>
  <p>Viši srednji, odnosno <strong>nivo B 2</strong> već donosi ozbiljnija znanja korejskog. Pa tako, svaki polaznik koji savlada kurs korejskog B 2 nivoa već može da učestvuje u razgovoru sa sagovornicima kojima je korejski maternji, čak i ako oni govore malo brže i tema mu nije baš u potpunosti poznata, a trebalo bi i da može da čita i piše duže tekstove na ovom jeziku.</p>
  <p>Kako je <strong> C 1 nivo</strong> takozvani Niži napredni nivo prema pravilima jezičkog okvira koji smo pomenuli, on se smatra i vrlo ozbiljnim nivoom poznavanja korejskog jezika kao stranog, odnosno drugog jezika. Kandidat koji uspešno završi kurs korejskog C 1 nivoa, u principu može da se snađe u gotovo svakoj vrsti razgovora, bez obzira na temu i da li sagovornici govore sporo, brzo, razgovetno ili ne. Na ovom nivou polaznik u izuzetno retkim slučajevima pravi greške u govoru, a poseduje visok nivo poznavanja reči, te može da piše tekstove različite tematike, dužine i vrste na korejskom jeziku, kao i da čita različite tekstove. Takođe, polaznik sa ovim nivoom znanja može nesmetano da učestvuje i u poslovnim razgovorima, te da što bi rekao naš narod navodi razgovor na svoju vodenicu, zahvaljujući dobrom poznavanju rečnika, kao i da prati predavanja na ovom jeziku, pa čak i ako mu tema predavanja nije u potpunosti poznata.</p>
  <p>I na kraju, najviši nivo poznavanja korejskog kao drugog jezika je Viši napredni nivo, to jest C 2 nivo. Kanidat koji sa uspehom savlada kurs korejskog <strong>C 2 nivoa</strong>  je, može se slobodno reći postao ekspert, u smislu da može da se snađe u svakom razgovoru, bez obzira na njegovu temu, te da može da čita i piše tekstove na korejskom bez obzira koja je njihova tema  i dužina.</p>

<br/>
<br/>
</div>

<div class="col-md-2 col-lg-2 col-sm-2 pull-right" style=" margin-top: 100px;">

<div class="sbarbody" id="sidebar_calendar" style="width: 100px;"><ul class="sbarlist"><li class="sbartitle">Maj 2018</li></ul><ul class="sbarlist sbarcontent"><table class="calendar" align="center"><tbody><tr><td colspan="5" valign="top">&nbsp;</td><td valign="top" class="sbarcalendar">1</td><td valign="top" class="sbarcalendar">2</td></tr>
<tr><td valign="top" class="sbarcalendar">3</td><td valign="top" class="sbarcalendar">4 </td><td valign="top" class="sbarcalendar">5</td><td valign="top" class="sbarcalendar">6</td><td valign="top" class="sbarcalendar">7</td><td valign="top" class="sbarcalendar">8</td><td valign="top" class="sbarcalendar">9</td></tr>
<tr><td valign="top" class="sbarcalendar">10</td><td valign="top" class="sbarcalendar">11</td><td valign="top" class="sbarcalendar">12</td><td valign="top" class="sbarcalendar">13</td><td valign="top" class="sbarcalendar">14</td><td valign="top" class="sbarcalendar">15</td><td valign="top" class="sbarcalendar">16</td></tr>
<tr><td valign="top" class="sbarcalendarposts"><a href="https://learn-korean.livejournal.com/2013/11/17/" target="_self">17</a></td><td valign="top" class="sbarcalendar">18</td><td valign="top" class="sbarcalendar">19</td><td valign="top" class="sbarcalendar">20</td><td valign="top" class="sbarcalendar">21</td><td valign="top" class="sbarcalendar">22</td><td valign="top" class="sbarcalendar">23</td></tr>
<tr><td valign="top" class="sbarcalendar">24</td><td valign="top" class="sbarcalendar">25 </td><td valign="top" class="sbarcalendar">26</td><td valign="top" class="sbarcalendar">27</td><td valign="top" class="sbarcalendar">28</td><td valign="top" class="sbarcalendar">29</td><td valign="top" class="sbarcalendar">30</td></tr>
</tbody></table></ul></div>


</div>
</div>



@endsection