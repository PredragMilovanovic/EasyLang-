@extends('layouts.app')
@section('content')
<style>
    .invalid-feedback{
        display :block;
    }
</style>



<body>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" >
        
    <div class="container" style="margin-top: 100px;">
    
        <div class="row>">
            @if (session()->has('flash_message'))
            <div class="alert alert-success">{{Session::get('flash_message')}}</div>
                @endif
            <div class="col-md-6">
                <h1> Kontaktirajte nas</h1>
<form method="post" action="{{route('contact.store')}}">
    {{csrf_field()}}
    <div class="form-group">
    <label>Ime: </label><br/>
    <input type="text" clas="form-control" name='name'>
   @if($errors->has('name'))
    <small class="form-text invalid-feedback">{{$errors->first('name')}}</small>
    @endif
</div>
<div class="form-group">
    <label>Email adresa: </label><br/>
    <input type="text" clas="form-control" name='email'>
    @if($errors->has('email'))
    <small class="form-text invalid-feedback">{{$errors->first('email')}}</small>
    @endif
</div>
<div class="form-group">
    <label>Poruka: </label>
    <textarea name="message" class="form-control"></textarea>
    @if($errors->has('message'))
    <small class="form-text invalid-feedback">{{$errors->first('message')}}</small>
    @endif

</div>
<button class="btn btn-primary">Posalji</button>


    </form></div></div></div>
</body>

@endsection
