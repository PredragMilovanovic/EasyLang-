
@extends('layouts.app')

@section('content')


<div clas="v" style=" margin-top: 100px;">

<div id="myCarousel" class="carousel slide" data-ride="carousel">

  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

 <div class="carousel-inner" role="listbox">

    <div class="item active">
        <img class="first-slide" src="https://lonelyplanetimages.imgix.net/a/g/hi/t/09a64fea2933f6da77ab07d671d1f678-south-korea.jpg?sharp=10&vib=20&w=1200" alt="First Slide"style="height: 500px; width: 100%; display: block;">
        <div class="container">
            <div class="carousel-caption" style=" font-weight:bold; height: 100%; font-weight:bold;">
                <h1>Naucite korejski besplatno!</h1>
                <h4>Nas kurs besplatnog ucenja korejskog jezika pomocice vam u tome!</h4>
            </div>
        </div>
    </div>

    <div class="item">
        <img class="second-slide" src="http://assets.signature-reads.com/wp-content/uploads/2017/09/education-quotes-shutterstock.jpg" alt="Second Slide" style="height: 500px; width: 100%; display: block;">
        <div class="container">
            <div class="carousel-caption" style=" font-weight:bold; height: 100%; font-weight:bold;">
                <h1>Ucenje je brzo i efikasno</h1>
                <h4>Ovim kursom korejskog jezika moci cete doseći A2 nivo Zajednickog evropskog referentnog okvira.</h4>
            </div>
        </div>
    </div>

    <div class="item">
        <img class="second-slide" src="https://www.learnupon.com/wp-content/uploads/create-engaging-mobile-learning-content.jpg" alt="Third Slide" style="height: 500px; width: 100%; display: block;">
        <div class="container">
            <div class="carousel-caption" style=" font-weight:bold; height: 100%; font-weight:bold;">
                <h1>Uvek dostupan</h1>
                <h4>Sajt je prilagodjen telefonima, tako da cete lako moci citati lekcije dok ste na primer u autobusu.</h4>
            </div>
        </div>
    </div>
 </div>

   <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Prethodna</span>
   </a>
   <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Sledeca</span>
    </a>

</div>
</div>
<br/>
<br/>
<hr class="featurette-divider">
<div class="container">
  <div class="row">
  <h1> Upoznajte osnove stranog vokabulara</h1>
  <h3>Naucite najvaznije reci na korejskom. </h3>
  <p>Na ovom kursu, upoznacete se sa osnovama stranog vokabulara.
Na temelju toga ćete već ubrzo biti u stanju složiti i razumeti jednostavne rečenice. Naucicete najvažnije pojmove vezane za sldeće teme:  </P>
 <p> životinje- u restoranu – rezervirati let – na aerodromu – pitati za smer – razgledavanje – šetnja gradom – poseta muzeju – novac  – povrede i bolesti – u apoteci – škola i fakultet – putovati vozom, busom ili avionom – na putu s autom – na benzinskoj pumpi – voće – povrće – kupiti namirnice – znanje o komunikaciji – telefoniranje – u bioskopu – odeća – države – kriminal – platiti račun – čitati sa sata – razgovor – sklopiti prijateljstvo – brojati na korejskom – zamenice – čitanje jelovnika – vremenska prognoza – najčešći pridjevi i njihove komparacije – meseci i godišnja doba – sportovi – kupovina – porodica – čuvati djecu – napisati pismo  – ponašanje kod nesreća – ljudsko telo – u hotelu – najvažniji glagoli – kuvati – organizirati izlet – uređivanje interijera – moda – nekoga pozdraviti – lepe reči kao što su hvala, molim, izvoli ... – i još mnogo toga !</p>
 <hr class="featurette-divider">
  <h3>Klasifikacija jezika </h3>
  <p>Klasifikacija korejskog jezika u sistemu svetskih jezika je još uvek predmet sporenja među filolozima. </p>
  <p>Veći broj istraživača smatra da je korejski jezik posebna grana altajske jezičke grupe, poput japanskog jezika. Postoje i mišljenja da se radi o izolovanom jeziku. </p>

  <p>Još značajnije su leksičke sličnosti sa altajskim jezicima. Međutim, ni samo postojanje familije altajskih jezika nije univerzalno prihvaćeno među naučnicima. </p>
  <p>Istorijski i danas postoji jaka strukturna veza korejskog sa japanskim, pri čemu postoje brojni oblici koji su po načinu tvorbe i značenju identični. Ipak, ne postoji sličnost u leksici. Za objašnjenje ovog fenomena još ne postoje zadovoljavajuće teorije. </p>
  <p>Sličnost sa kineskim jezikom je jedino u pozajmljenim rečima, koje su posledica kulturne bliskosti. Korejski jezik nema strukturnih sličnosti sa sino-tibetanskim jezicima. </p>
  <hr class="featurette-divider">

  </div>
</div>

<br/>
<br/>

<div class="container">
<div class="container marketing">


<div class="row">
  <div class="col-lg-4">
    <img class="rounded-circle" src="http://www.highpoint.edu/library/files/2016/04/relax.jpg" alt="Generic placeholder image" width="300" height="180">
    <h2>Uljepšajte svoje slobodno vreme!</h2>
    <p>Možete gledati filmove na korejskom! Kakav užitak je čitati knjigu na korejskom!</p>
  </div>
  <div class="col-lg-4">
    <img class="rounded-circle" src="https://ocdn.eu/pulscms-transforms/1/v6Tk9lMaHR0cDovL29jZG4uZXUvaW1hZ2VzL3B1bHNjbXMvTURZN01EQV8vZGZjMzRhOGJhMGFkMWIyZWI3MmJjMzM2ZmYyOTJmZjUuanBlZ5GTAs0C5ACBoTAB" alt="Generic placeholder image" width="300" height="180">
    <h2>Duhovno se bolje osecate!</h2>
    <p>Zdravstvena istraživanja pokazuju:
Bolje obrazovanje povećava kvalitet zivota i ocekivanje.
Trenirajte svoj mozak.
Studije su pokazale, da učenje jezika pomaže u sprečavanju dementnosti i alzheimera.</p>
   
  </div>
  <div class="col-lg-4">
    <img class="rounded-circle" src="http://viettour.com.vn/upload/images/Changdeokgung-cung-dien-truyen-thong-o-han-quoc.jpg" alt="Generic placeholder image" width="300" height="180">
    <h2>Svako putovanje će postati nezaboravan doživljaj!</h2>
    <p>Proširite svoje horizonte boravkom u Koreji.
Ako znate korejski, to će putovanje biti nezaboravan doživljaj za Vas.
Zemlju i njene stanovnike ćete puno bolje razumeti i upoznati.
Ako znate korejski, bez problema ćete se snaći u u Koreji, lakše ćete se informirati i domaće pitati za pomoć.</p>
    
  </div>
</div>
</div>

 <hr class="featurette-divider">

<div class="row featurette">
  <div class="col-md-7 order-md-1">
    <h2 class="featurette-heading">Poznavanje korejskog pisma u mnogome ce vam pomoci. <span class="text-muted"></span></h2>
    <p class="lead">Korejsko pismo ili Hangul sapada u veoma laka pisma za ucenje. Slova su tako formirana da oponasaju oblik usana tokom njihovog izgovora. Citanjem korejskih reci lakse cete uciti jezik. Lekcija o korejskom pismu veoma je jednostavno prilagodjena, kako bi ste sto jednostavnije naucili. Posle veoma kratkog vremenskog roka mocicete da prepoznate sva slova i da pravilno izgovarate sve recenice.</p>
  </div>
  <div class="col-md-5 order-md-2">
    <img class="featurette-image img-fluid mx-auto" data-src="holder.js/500x500/auto" alt="500x500" src="http://www.wright-house.com/korean/korean-graphics/linguistics/consonants-5-groups-diagram.gif" data-holder-rendered="true" style="width: 500px; height: 500px;">
  </div>
</div>

<hr class="featurette-divider">

<div class="row featurette">
 <div class="col-md-5 order-md-1">
    <img class="featurette-image img-fluid mx-auto" data-src="holder.js/500x500/auto" alt="500x500" src="http://www.kolektiv.me/cache/images/14-05-2018/743-418-5ac8ba87ab8c6.jpg" data-holder-rendered="true" style="width: 450px; height: 400px;">
  </div>
  <div class="col-md-7 order-md-2">
    <h2 class="featurette-heading">I na kraju, jos ovo.<span class="text-muted">Chetovanje.</span></h2>
    <p class="lead">Mocicete komunicirati sa drugim korisnicima sajta putem cheta. Razmenjivati misljenja i iskustva. Dobiti preporuku i preporuciti nekome sta ste vi naucili i koje su lekcije najbolje. Mocicete dodavati  svoje lekcije i obavestiti druge da ste ih upravo postavili. </p>
  </div>
</div>

<hr class="featurette-divider">

<!-- /END THE FEATURETTES -->

</div>


<br/>
<br/>
<br/>
<br/>



<footer class="container">
        
        <p>©2018 ALPHA_team  *<a href="#">Povratak na vrh</a> </p>
</footer>

@endsection
