@extends('layouts.app')

@section('content')

<nav class="col-md-2 col-lg-2 col-sm-2  d-md-block bg-light sidebar-static "style=" height: 100%;width: 160px;position: fixed;z-index: 1;top: 0;left: 0;background-color: #111;overflow-x: hidden;padding-top: 20px; margin-top:40px;" >
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
            <li class="nav-item">

            <form method="get" action="{{url('/searchcontent')}}" class="navbar-form navbar-lefte" role="search">
            <div class="input-group custom-search-form ">
            <input type="text" class="form-control" name="search" placeholder="Trazi">
            <span class="input-group-btn">
            <button class="btn btn-default-sm" type="submit">
            <i class="fa fa-search"> *</i>
             </button>
            </span>
           </div>
          </form>

            </li>
              <li class="nav-item">
                <a class="nav-link active" href="{{ url('/home') }}">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                  Pocetna <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/lessons">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file-text"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                  Lekcije
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/contents">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
                  Kategorije
                </a>
              </li>
             
            </ul>

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Dodaj novu lekciju</span>
              <a class="d-flex align-items-center text-muted" href="/lessons/create">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
              </a>
            </h6>

            <ul class="nav flex-column mb-2">

            <li class="nav-item">
                <a class="nav-link" href="{{ url('/dashboard') }}">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                  Chat
                </a>
              </li>

            <li class="nav-item">
                <a class="nav-link" href="{{ url('/contact') }}">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                  Kontaktirajte nas
                </a>
              </li>
            </ul>

          </div>
</nav>
        
<div class="pricing-header px-3 py-3 pt-md-4 pb-md-offset-3 mx-auto text-center" style="margin-left:160px; margin-top: 100px;">
      <h1 class="display-4">Lekcije poznatih predavaca</h1>
      <p class="lead">Na ovom sajtu pored onsovnih lekcija mozete pratiti i predavanja svetski poznatih predavaca. Lekcije pored tekstualnih objasnjenja sadrze i video snimke u najboljoj rezoluciji.</p>
</div>

   <br/>
   <br/>
      <div class="card-deck  col-md-10 mx-auto text-center pull->right"style="margin-left:160px">
        <div class="card col-md-3 mx-auto box-shadow pull->left col-md-offset-1">
          <div class="card-header">
            <h4 class="my-0 font-weight-normal">Free</h4>
          </div>
          <div class="card-body">
            <h1 class="card-title pricing-card-title" style="color:#ef1602 ">$0 <small class="text-muted">/mo</small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li>3 meseca</li>
              <li>2 GB memorije za podatke</li>
              <li>HD rezolucija</li>
              <li>Pristup svim lekcijama </li>
            </ul>
            <button type="button" class="btn btn-lg btn-block">Prijavi se besplatno</button>
          </div>
        </div>

        <div class="card col-md-3 box-shadow pull->left col-md-offset-1">
          <div class="card-header">
      
            <h4 class="my-0 font-weight-normal">Pro</h4>
          </div>
          <div class="card-body">
            <h1 class="card-title pricing-card-title" style="color:#ef1602 ">$15 <small class="text-muted">/mo</small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li>6 meseci</li>
              <li>10 GB memorije za podatke</li>
              <li>HD rezolucija</li>
              <li>Pristup svim lekcijama</li>
            </ul>
            
            <button onclick="location.href='{{ route('register') }}'" type="button" class="btn btn-lg btn-block btn-primary">Pocnite</button>
         
          </div>
        </div>

        <div class="card col-md-3 box-shadow pull->left col-md-offset-1">
          <div class="card-header">
            <h4 class="my-0 font-weight-normal">Enterprise</h4>
          </div>
          <div class="card-body">
            <h1 class="card-title pricing-card-title" style="color:#ef1602 ">$29 <small class="text-muted">/mo</small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li>Godinu dana</li>
              <li>15 GB memorije za podatke</li>
              <li>HD rezolucija</li>
              <li>Pristup svim lekcijama</li>
            </ul>
            <button onclick="location.href='{{ url('/contact') }}'" type="button" class="btn btn-lg btn-block btn-primary">Kontaktirajte nas</button>
          </div>
        </div>
        
      </div>

<br/>
<br/>
<div class="body-display col-md-11" style="margin-top: 40px;margin-left:150px; margin-right:5px;">
     

      <div class="jumbotron col-md-12 col-sm-12 text-white rounded bg-dark"style="background-color:#91fc85">
        <div class="col-md-12 col-sm-12 px-0">
          <h1 class="display-4 font-italic">Jedinstvene metode s kojima ćete u rekordnom vremenu naučiti korejski jezik</h1>
          <p class="lead my-3">"Metoda dugoročnog pamćenja i svakodnevni zadaci, najvažniji su deo ovog kursa za korejski jezik.
Raspored lekcija će vam omogućiti da kvalitetno ispuniti svoj kapacitet učenja.
U našoj grupi za učenje možete s drugima izmjenjivati znanje i družiti se.
Tamo ćete dobiti korisne savete i upoznati nove ljude.</p>
          <p class="lead mb-0"><a href="/lessons" class="text-white font-weight-bold">Nastavi sa citanjem...</a></p>
        </div>
      </div>

      <div class="row mb-2">
        <div class="col-md-6 col-sm-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">Standard</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="/htmlstrane/str1">Međunarodno priznat standard za učenje korejskog jezika</a>
              </h3>
              <div class="mb-1 text-muted">Maj 17</div>
              <p class="card-text mb-auto">Kako škole stranih jezika posluju u skladu sa važećim standardima u nastavi jezika, to isto važi i kada je u pitanju kurs korejskog jezika..</p>
              <a href="{{ url('/htmlstrane/str1') }}">Nastavi sa čitanjem</a>
            </div>
            
            <img class="card-img-right flex-auto d-none d-lg-block" src="https://www.17-minute-languages.com/grafik/Koreanisch_Box_Basis1_A300.jpg" data-holder-rendered="true"  style="width: 200px; height: 250px;">
          </div>
        </div>
        <div class="col-md-6 col-sm-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-success">Metode</strong>
              <h3 class="mb-0">
              
                <a class="text-dark" href="https://www.17-minute-languages.com/hr/u%C4%8Denje-korejskog/">Raznoliki načini učenja koji će vas motivisati na dalji rad</a>
              </h3>
              <div class="mb-1 text-muted">Apr 25</div>
              <p class="card-text mb-auto">Kako bi učenje ostalo interesanto, ubacili smo mnoge nove trikove i pomagala, koji će povećati vašu motivaciju i...</p>
              <a href="https://www.17-minute-languages.com/hr/u%C4%8Denje-korejskog/">Nastavi sa čitanjem</a>
            </div>
            <img class="card-img-right flex-auto d-none d-lg-block" src="https://ddl.rs/wp-content/uploads/2018/03/learn-language-2001847_1280.jpg" data-holder-rendered="true" style="width: 300px; height: 250px;">
          </div>
        </div>
      </div>
    </div>
    
</div>

@endsection