@extends('layouts.app')

@section('content')

<div class="container" style=" margin-top: 100px;">
<div class="row">

@if(count($lessons)>0)
@foreach($lessons as $lesson)

{{$lesson->id}}  
<a href="/lessons/{{$lesson->id}}">{{$lesson->name}}</a>
<br/>

@endforeach
@else
<h1> Nista nije pronadjeno!</1>
@endif


</div>
</div>

@endsection