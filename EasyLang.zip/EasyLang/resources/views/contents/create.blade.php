@extends('layouts.app')

@section('content')

<div class="row col-md-9 pull-left" style=" margin-top: 100px; margin-left:10px;">
<div class="row col-md-12">
  
  <form method="post" action="{{route('contents.store')}}">
       {{csrf_field()}}

       

       <div class="form-group">
         <label for="content-name">Ime kategorije<span class="required">*</span></label>
         <input placeholder="Unesite ime"
                id="content-name"
                required
                name="name"
                spellcheck="false"
                class="form-control"
                />
        </div>   

        <div class="form-group">
         <label for="content-content">Opis kategorije<span class="required">*</span></label></label>
         <textarea placeholder="Dodaj opis"
                style="resize:vertical"
                id="content-content"
                name="description"
                rows="S"
                spellcheck="false"
                class="form-control autosize-target text-left">
               
                </textarea>
        
        </div>   

        <div class="form-group">
           <input type="submit" class="btn btn-primary" value="Sacuvaj"  />
        </div>  
   </form>

</div>
</div>

<div class="col-md-3 col-lg-3 col-sm-3 pull-right" style=" margin-top: 100px;">

<div class="sidebar-module">
<h4> Akcija </h4>
       <li> <a href="/contents"> Moje kategorije </a></li>
    </ol>
</div>

</div>

@endsection