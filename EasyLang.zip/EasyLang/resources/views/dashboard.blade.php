@extends('layouts.app')
@section('content1')

<style type="text/css">
.img
{
    background-image:url("https://i2.wp.com/littleholidays.net/wp-content/uploads/2017/09/Autumn-in-South-Korea-%E2%80%93-the-best-spots-for-leaf-viewing-in-South-Korea.jpg?fit=2000%2C1200&ssl=1");
    background-size:cover;
    
    background-repeat: no-repeat;
}

 </style>
 <body class="img" style=" margin-top: 100px; margin-left:10px; margin-right:10px;">
     <section class="row posts" >

        <div class="col-md-6 col-md-offset-3"><h3 style="color: white;" >Sta su drugi ljudi rekli...</h3></div>
        <div class="col-md-6 col-md-offset-3" style="width:50%;height:250px;overflow:scroll;">
            @foreach($posts as $post)
            <article class="post panel panel-success"  data-postid="{{$post->id}}">
                <div class="info panel-heading" style="margin-left: ;">
                {{$post->user->name}} {{$post->created_at}}
            </div>
            <div class='panel-body' style="margin-left:20px;">{{$post->body}}</div>
        </article>
        @endforeach
        </div>
    </div>
     </section>
     <section class="row new-post">
         <div class="col-md-6 col-md-offset-3">
             <header><h3 style="color: white;">Sta ti imas da kazes</h3></header>
             <form action="{{route('post.create')}}" method="post">
            <div class="form-group">
                <textarea class="form-control" name="body" id="new-post" rows="5" placeholder="posalji poruku"></textarea></textarea>
                </div>
            <button type="submit" class="btn btn-primary">Posalji poruku</button>
            <input type="hidden" value="{{Session::token()}}" name="_token">
            </form>
         </div>
     </section><br>
 </body>
 <script>
     var token="{{Session::token()}}";
 </script>
 @endsection