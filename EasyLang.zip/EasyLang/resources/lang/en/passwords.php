<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'password' => 'Lozinka mora sadrzati najmanje 6 karaktera.',
    'reset' => 'Vasa lozinka je resetovana!',
    'sent' => 'Link za resetovanje lozinke je poslat na vas e-mail!',
    'token' => 'Resetovanje lozinke nije validno.',
    'user' => "Ne mozemo pronaci korisnika sa tom e-mail adresom.",

];
