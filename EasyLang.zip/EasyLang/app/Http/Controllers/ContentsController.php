<?php

namespace App\Http\Controllers;

use App\Content;
use Illuminate\Http\Request;

class ContentsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $contents = Content::all();
        return view('contents.index', ['contents'=>$contents]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('contents.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(Auth::check()){
            $content=Content::create([
                'name'=>$request->input('name'),
                'description'=>$request->input('description'),
                'user_id'=>Auth::user()->id
            ]);

            if($content){
                return redirect()->route('contents.show',['content'=>$content->id])->with('success','Kategorija je uspesno kreirana!');
            }

        }
        return back()->withInput()->with('errors','Kategorija ne moze biti kreirana.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Content  $content
     * @return \Illuminate\Http\Response
     */
    public function show(Content $content)
    {
        $content = Content::find($content->id);
        return view('contents.show', ['content'=>$content]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Content  $content
     * @return \Illuminate\Http\Response
     */
    public function edit(Content $content)
    {
        $content = Content::find($content->id);
        return view('contents.edit', ['content'=>$content]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Content  $content
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Content $content)
    {
        $contentUpdate=Content::where('id',$content->id)
        ->update([
            'name'=>$request->input('name'),
            'description'=>$request->input('description')

        ]);

        if($contentUpdate){
            return redirect()->route('contents.show',['content'=>$content->id])->with('success','Kategorija je uspesno izmenjena!') ; 
          }
        
            return back()->withInput()->with('errors','Kategorija ne moze biti izmenjena.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Content  $content
     * @return \Illuminate\Http\Response
     */
    public function destroy(Content $content)
    {
        $findContent=Content::find($content->id);
        if($findContent->delete()){
            return redirect()->route('contents.index')->with('success','Kategorija je uspesno obrisana!');
        }

        return back()->with('errors','Kategorija ne moze biti obrisana');
    }
}
