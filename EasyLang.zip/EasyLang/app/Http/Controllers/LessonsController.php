<?php

namespace App\Http\Controllers;

use App\Lesson;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LessonsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $lessons = Lesson::all();
        return view('lessons.index', ['lessons'=>$lessons]);

       
    }

    public function searchcontent()
    {
        $search = \Request::get('search'); //<-- we use global request to get the param of URI
 
        $lessons = Lesson::where('name','like','%'.$search.'%')
            ->orderBy('id')
            ->paginate(20);
     
        return view('searchcontent',['lessons'=>$lessons]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('lessons.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(Auth::check()){
            $lesson=Lesson::create([
                'name'=>$request->input('name'),
                'description'=>$request->input('description'),
                'user_id'=>Auth::user()->id
                
            ]);

            if($lesson){
                return redirect()->route('lessons.show',['lesson'=>$lesson->id])->with('success','Lekcija je uspesno kreirana!');
            }

        }
        return back()->withInput()->with('errors','Lekcija ne moze biti kreirana');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Lesson  $lesson
     * @return \Illuminate\Http\Response
     */
    public function show(Lesson $lesson)
    {
        $lesson = Lesson::find($lesson->id);
        return view('lessons.show', ['lesson'=>$lesson]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Lesson  $lesson
     * @return \Illuminate\Http\Response
     */
    public function edit(Lesson $lesson)
    {
        $lesson = Lesson::find($lesson->id);
        return view('lessons.edit', ['lesson'=>$lesson]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Lesson  $lesson
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Lesson $lesson)
    {
        $lessonUpdate=Lesson::where('id',$lesson->id)
        ->update([
            'name'=>$request->input('name'),
            'description'=>$request->input('description')

        ]);

        if($lessonUpdate){
            return redirect()->route('lessons.show',['lesson'=>$lesson->id])->with('success','Lekcija je uspesno izmenjena!') ; 
          }
        
            return back()->withInput()->with('errors','Lekcija ne moze biti izmenjena');;
     }


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Lesson  $lesson
     * @return \Illuminate\Http\Response
     */
    public function destroy(Lesson $lesson)
    {
        $findLesson=Lesson::find($lesson->id);
        if($findLesson->delete()){
            return redirect()->route('lessons.index')->with('success','Lekcija je uspesno obrisana!');
        }

        return back()->with('errors','Lekcija ne moze biti obrisana');
    }
}
