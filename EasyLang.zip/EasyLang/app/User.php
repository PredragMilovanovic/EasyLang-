<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function lessons(){
        return $this->hasMany('App\Lesson');
    }
    public function comments(){
        return $this->hasMany('App\Comment');
    }
    public function lesson(){
        return $this->belongsToMany('App\Lesson');
    }
    public function contents(){
        return $this->hasMany('App\Content');
    }
    public function content(){
        return $this->belongsToMany('App\Content');

        
    }
    public function chats()
    {
        return $this->hasMany('App\chat');

    }
    public function likes(){
        return $this->hasMany('App\like');
    }

}
