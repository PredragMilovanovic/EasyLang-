<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LessonUser extends Model
{
    public function users(){
        return $this->belongsToMany('App\User');
    }
    public function lessons(){
        return $this->belongsToMany('App\Lesson');
    }
}
