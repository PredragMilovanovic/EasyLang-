<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContentUser extends Model
{
    public function users(){
        return $this->belongsToMany('App\User');
    }
    public function contents(){
        return $this->belongsToMany('App\Content');
    }
}
