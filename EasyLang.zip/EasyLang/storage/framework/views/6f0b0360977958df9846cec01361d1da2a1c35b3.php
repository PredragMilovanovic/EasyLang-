<?php $__env->startSection('content'); ?>

<div class="container" style=" margin-top: 100px;">
<div class="row">

<?php if(count($lessons)>0): ?>
<?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php echo e($lesson->id); ?>  
<a href="/lessons/<?php echo e($lesson->id); ?>"><?php echo e($lesson->name); ?></a>
<br/>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<h1> Nista nije pronadjeno!</1>
<?php endif; ?>


</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>