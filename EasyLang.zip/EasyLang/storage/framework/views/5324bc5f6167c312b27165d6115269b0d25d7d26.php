<?php $__env->startSection('content1'); ?>

<style type="text/css">
.img
{
    background-image:url("https://i2.wp.com/littleholidays.net/wp-content/uploads/2017/09/Autumn-in-South-Korea-%E2%80%93-the-best-spots-for-leaf-viewing-in-South-Korea.jpg?fit=2000%2C1200&ssl=1");
    background-size:cover;
    
    background-repeat: no-repeat;
}

 </style>
 <body class="img" style=" margin-top: 100px; margin-left:10px; margin-right:10px;">
     <section class="row posts" >

        <div class="col-md-6 col-md-offset-3"><h3 style="color: white;" >Sta su drugi ljudi rekli...</h3></div>
        <div class="col-md-6 col-md-offset-3" style="width:50%;height:250px;overflow:scroll;">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="post panel panel-success"  data-postid="<?php echo e($post->id); ?>">
                <div class="info panel-heading" style="margin-left: ;">
                <?php echo e($post->user->name); ?> <?php echo e($post->created_at); ?>

            </div>
            <div class='panel-body' style="margin-left:20px;"><?php echo e($post->body); ?></div>
        </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
     </section>
     <section class="row new-post">
         <div class="col-md-6 col-md-offset-3">
             <header><h3 style="color: white;">Sta ti imas da kazes</h3></header>
             <form action="<?php echo e(route('post.create')); ?>" method="post">
            <div class="form-group">
                <textarea class="form-control" name="body" id="new-post" rows="5" placeholder="posalji poruku"></textarea></textarea>
                </div>
            <button type="submit" class="btn btn-primary">Posalji poruku</button>
            <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token">
            </form>
         </div>
     </section><br>
 </body>
 <script>
     var token="<?php echo e(Session::token()); ?>";
 </script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>