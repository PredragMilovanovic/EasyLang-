<?php $__env->startSection('content'); ?>
<style>
    .invalid-feedback{
        display :block;
    }
</style>



<body>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" >
        
    <div class="container" style="margin-top: 100px;">
    
        <div class="row>">
            <?php if(session()->has('flash_message')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('flash_message')); ?></div>
                <?php endif; ?>
            <div class="col-md-6">
                <h1> Kontaktirajte nas</h1>
<form method="post" action="<?php echo e(route('contact.store')); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
    <label>Ime: </label><br/>
    <input type="text" clas="form-control" name='name'>
   <?php if($errors->has('name')): ?>
    <small class="form-text invalid-feedback"><?php echo e($errors->first('name')); ?></small>
    <?php endif; ?>
</div>
<div class="form-group">
    <label>Email adresa: </label><br/>
    <input type="text" clas="form-control" name='email'>
    <?php if($errors->has('email')): ?>
    <small class="form-text invalid-feedback"><?php echo e($errors->first('email')); ?></small>
    <?php endif; ?>
</div>
<div class="form-group">
    <label>Poruka: </label>
    <textarea name="message" class="form-control"></textarea>
    <?php if($errors->has('message')): ?>
    <small class="form-text invalid-feedback"><?php echo e($errors->first('message')); ?></small>
    <?php endif; ?>

</div>
<button class="btn btn-primary">Posalji</button>


    </form></div></div></div>
</body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>