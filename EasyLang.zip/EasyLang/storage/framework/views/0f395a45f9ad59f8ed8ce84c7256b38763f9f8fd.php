<?php if(session()->has('success')): ?>
   <div class="alert alert-dismissable alert-success col-md-offset-2" style="margin-top: 60px;">
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
     <span aria-hidden="true">&times;</span>
     </button>

     <strong>
    <?php echo e(session()->get('success')); ?>

     </strong>
    </div>

<?php endif; ?>
