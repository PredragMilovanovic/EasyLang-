<?php $__env->startSection('content'); ?>

<main role="main" class="col-md-12 pull-center">

      <section class="jumbotron text-center">
        
        <h1 class="jumbotron-heading">Zivotinje</h1>
        <p class="lead text-muted">동물 (dongmul)</p>
      
    </section>

      <div class="album py-5 bg-light">
       

          <div class="row">
            <div class="col-md-4">
              <div class="card mb-4 box-shadow">
                <img class="card-img-top" src="http://www.tarot.hr/wp-content/uploads/2016/11/pas-medo.jpg" data-holder-rendered="true" style="height: 225px; width: 100%; display: block;" >
                <div class="card-body" style="text-align: center;">
                  <p class="card-text" >개 (ke)</p>
                  
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card mb-4 box-shadow">
                <img class="card-img-top" src="http://www.superljubimac.rs/pictures/s4-americko-kratkodlako-mace.jpg" data-holder-rendered="true" style="height: 225px; width: 100%; display: block;">
                <div class="card-body" style="text-align: center;">
                  <p class="card-text" style="font:12px; text-align:centre;"> 고양이 (kujani)</p>
                 
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card mb-4 box-shadow">
                <img class="card-img-top" src="http://www.medias.rs/images/5/544/monarch_butterfly_-_butterfly_place_in_westford_massachusetts_2.jpg" data-holder-rendered="true" style="height: 225px; width: 100%; display: block;">
                <div class="card-body" style="text-align: center;">
                  <p class="card-text">나비 (napi)</p>
                  
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card mb-4 box-shadow">
                <img class="card-img-top" src="http://www.edutelevision.com/wp-content/uploads/2017/07/zeleni-tanager.jpg" data-holder-rendered="true" style="height: 225px; width: 100%; display: block;">
                <div class="card-body" style="text-align: center;">
                  <p class="card-text">새 (se)</p>
                  
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 box-shadow">
                <img class="card-img-top" src="https://www.natura.rs/images/stories/arapski-konj-01.jpg" data-holder-rendered="true" style="height: 225px; width: 100%; display: block;">
                <div class="card-body" style="text-align: center;">
                  <p class="card-text">말 (mal)</p>
                  
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 box-shadow">
                <img class="card-img-top" src="https://www.njuz.net/wp-content/uploads/2017/05/majmun-680x430.jpg" data-holder-rendered="true" style="height: 225px; width: 100%; display: block;">
                <div class="card-body" style="text-align: center;">
                  <p class="card-text">원숭이 (vansuni)</p>
                  
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card mb-4 box-shadow">
                <img class="card-img-top" src="http://www.vosvetlelasky.sk/Obrazky/slon.jpg" data-holder-rendered="true" style="height: 225px; width: 100%; display: block;">
                <div class="card-body" style="text-align: center;">
                  <p class="card-text">코끼리 (kokiri)</p>
                  
                    
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 box-shadow">
                <img class="card-img-top" src="http://www.zivotinje.rs/upload/vesti/textImagesNovi/slike_1/zmije/mis.jpg" data-holder-rendered="true" style="height: 225px; width: 100%; display: block;">
                <div class="card-body" style="text-align: center;">
                  <p class="card-text">쥐 (či)</p>
                  
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 box-shadow">
                <img class="card-img-top" src="http://www.nationalgeographic.rs/thumbnail.php?file=Jelen_964097760.jpg&size=article_large" data-holder-rendered="true" style="height: 225px; width: 100%; display: block;">
                <div class="card-body" style="text-align: center;">
                  <p class="card-text">사슴 (sasm) </p>
              </div>
            </div>
          </div>
        </div>
      </div>

    </main>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>